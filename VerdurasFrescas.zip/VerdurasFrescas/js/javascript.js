(function(){

	var cedula=document.getElementById("cedula"),
		btnValidar= document.getElementById("btnValidar"),
		chkFisica=document.getElementById("fisica"),
		chkJuridica=document.getElementById("juridica");

	var validarCedula = function(e){
		if(cedula.value ==0){
			alert("Ingrese su cedula");
			e.preventDefault();
		}else if(cedula.value.length<10){
			alert("Cedula invalida. Ingrese su cedula nuevamente");
			e.preventDefault();
			cedula.value = "";
			cedula.focus();
		}
	};

	var validarCheckboxes = function(e){
		if(fisica.checked != true && juridica.checked != true){
			alert("Seleccione Tipo de Cedula");
			e.preventDefault();
		}
	}
	
	var validar  = function(e){
		validarCedula(e);
		validarCheckboxes(e);
	};

	//Funcion que valida que solo se ingrese texto
	var s= function soloTexto(evt) {
		//Si se presiona una tecla diferente de Suprimir o Tab o Enter
		if(evt.keyCode!=8 && evt.keyCode!=9 && evt.keyCode!=13)
   		{
	        var theEvent = evt || window.event;
	        var key = theEvent.keyCode || theEvent.which;
	        key = String.fromCharCode(key);
	        var regex = /[0-9]|\./;
	        //Valida que solo se ingresen numeros
	        if (!regex.test(key))
	        {
	            theEvent.returnValue = false;

	            if (theEvent.preventDefault)
	                theEvent.preventDefault();
	        }
	    }
	    //Si se presiona Enter
	    if (evt.keyCode==13){
	    	//evita que se haga submit al presionar enter
	    	evt.preventDefault();
	    	//Se avtiva el Focus del boton btnValidar
	    	btnValidar.focus();
	    }

	};

	/*var textoMaximo= function cambiarTextoMaxSize() {
		alert("hola");
		if(fisica.checked){
			alert("hola2");
			cedula.setAttribute("maxlength", 10);
		}

	};*/


	//fisica.addEventListener("change", textoMaximo);
	btnValidar.addEventListener("click", validar);
	//cedula.addEventListener("keydown", s, false);



}());